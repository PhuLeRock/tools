cent5repo()
{
	yum -y groupinstall "Development Tools"
	yum -y install wget
	wget http://dl.fedoraproject.org/pub/epel/5/i386/epel-release-5-4.noarch.rpm
	wget http://rpms.famillecollet.com/enterprise/remi-release-5.rpm
	rpm -Uvh remi-release-5*.rpm epel-release-5*.rpm
	wget http://packages.sw.be/rpmforge-release/rpmforge-release-0.5.2-2.el5.rf.x86_64.rpm
	rpm --import http://apt.sw.be/RPM-GPG-KEY.dag.txt
	rpm -K rpmforge-release-0.5.2-2.el5.rf.*.rpm
	rpm -i rpmforge-release-0.5.2-2.el5.rf.*.rpm
}

cent6repo()
{
	yum -y groupinstall "Development Tools"
	yum -y install wget
	wget http://dl.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm
	wget http://rpms.famillecollet.com/enterprise/remi-release-6.rpm
	rpm -Uvh remi-release-6*.rpm epel-release-6*.rpm
	wget http://packages.sw.be/rpmforge-release/rpmforge-release-0.5.2-2.el6.rf.x86_64.rpm
	rpm --import http://apt.sw.be/RPM-GPG-KEY.dag.txt
	rpm -K rpmforge-release-0.5.2-2.el6.rf.x86_64.rpm 
	rpm -ivh rpmforge-release-0.5.2-2.el6.rf.x86_64.rpm

	sed -i "s/mirrorlist=https/mirrorlist=http/" /etc/yum.repos.d/epel.repo
}

installbase()
{
	yum install -y ntp.x86_64 nc.x86_64 tcpdump.x86_64 dstat telnet mlocate
}

vntimezone()
{
	rm -rf /etc/localtime;
	cp /usr/share/zoneinfo/Asia/Ho_Chi_Minh /etc/localtime;
	/etc/init.d/ntpd stop;  ntpdate 0.centos.pool.ntp.org; /etc/init.d/ntpd start
	chkconfig --level 234 ntpd on
}

disselinux()
{
	echo "SELINUX=disabled" > /etc/selinux/config; echo "SELINUXTYPE=targeted" >> /etc/selinux/config; setenforce 0
}

mkbasedir()
{
	mkdir -p /ssg/script /data /source /report/output /report/shell_log
	chmod 777 /report/shell_log
}

shellogging()
{
	echo 'DATE=`date +%d-%m-%y.%H:%M:%S`' >> /etc/profile
	echo "USERL=`whoami`" >> /etc/profile
	echo 'touch /report/shell_log/$USERL.$DATE' >> /etc/profile
	echo 'FILE_LOGGING=/report/shell_log/$USERL.$DATE' >> /etc/profile
	echo 'script -q -a -f $FILE_LOGGING' >> /etc/profile
}

sshkeyconfig()
{
	if  [ ! -d  /root/.ssh ]; then
	mkdir /root/.ssh
	chmod 755 /root/.ssh
	fi
	if [  -f  /root/.ssh/authorized_keys ]; then
	mv /root/.ssh/authorized_keys /root/.ssh/authorized_keys.bk
	fi
	cp authorized_keys /root/.ssh/authorized_keys
	chmod 0600 /root/.ssh/authorized_keys
	cp -r tunnel_keys /root/.ssh/
	chmod 755 /root/.ssh/tunnel_keys
	chmod 0600 /root/.ssh/tunnel_keys/tunnel_key.dsa
}

sshdconfig()
{
	mv /etc/ssh/sshd_config /etc/ssh/sshd_config.bk
	cp sshd_config /etc/ssh/
	/etc/init.d/sshd restart
}

if [ "$1"  = "centos5" ]
then
	echo xxxxxx cent5repo
	cent5repo
	echo xxxxxx disselinux
	disselinux
	echo xxxxxx installbase
	installbase
	echo xxxxxx vntimezone
	vntimezone
	echo xxxxxx mkbasedir
	mkbasedir
	echo xxxxxx shellogging
	shellogging
	echo xxxxxx sshdconfig
	sshdconfig
	echo xxxxxx sshkeyconfig
	sshkeyconfig
	
elif [ "$1"  = "centos6" ]; 
then
	echo xxxxxx cent6repo
	cent6repo
	echo xxxxxx disselinux
	disselinux
	echo xxxxxx installbase
	installbase
	echo xxxxxx vntimezone
	vntimezone
	echo xxxxxx mkbasedir
	mkbasedir
	echo xxxxxx shellogging
	shellogging
	echo xxxxxx sshdconfig
	sshdconfig
	echo xxxxxx sshkeyconfig
	sshkeyconfig
	
elif [ "$1"  = "--help" -o "$1"  = "" ]
then
	echo '
	run ./freshinstall.sh {option} or  ./freshintall.sh --help
	option:
	centos5: if you want to install for centos5.x
	centos6: if you want to install for centos6.x
	'
fi
	

